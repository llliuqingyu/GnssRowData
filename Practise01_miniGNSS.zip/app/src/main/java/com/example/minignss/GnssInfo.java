package com.example.minignss;

/*
感觉这么多卫星，接受到的数据不应该是多个吗，是不是因为手机是单频的，所以只跟踪一个卫星的数据，
只能获取到一组变量。那我这个软件就不能在双频手机上用了啊
 */
public class GnssInfo {


    /*
    接收机时钟测量值
     */
//    private final double BiasNanos;//时钟的亚纳秒偏置
//    private final double BiasUncertaintyNanos;//以纳秒为单位的时钟偏差不确定度
//    private final double DriftNanosPerSecond;//时钟的漂移，以纳秒为单位
//    private final double DriftNanosUncertaintyPerSecond;//时钟的漂移不确定性，以纳秒为单位
//    private final long   FullBaisNanos;//GPS接收机内部硬件时钟，与1980年1月6号0点以来的真实GPS时间之间的差异，以纳秒为单位
//    private final int    HardwareClockDiscontinuityCount;//硬件时钟不连续的计数
//    private final int    LeapSecond;//与时钟相关的闰秒
//    private final long    TimeNanos;//GNSS接收器内部硬件时钟值
//    private final double TimeUncertaintyNanos;//时钟的时间不确定性，以纳秒为单位

    /*
    GNSS卫星测量的类别，包含原始和计算的信息
     */
    private final long CarrierCycles;//卫星和接收机之间的全载波周期数
    private final float CarrierFrequencyHz;//代码和信息调制的载波频率
    private final double CarrierPhase;//接收机检测到的RF相位
    private final double CarrierPhaseUncertainty;//载波相位不确定性
//    private final double CnODbHz;//以DB-Hz为单位的载噪比密度
//    private final int  ConstellationTpye;//星座类型
//    private final int  MultipathIndicator;//指示事件“多路径”状态的值
//    private final double PseudorangeRateMetersPerSecond;//时间戳中的伪距速率，单位：米每秒
//    private final double PseudorangeRateUncertaintyMetersPerSecond;//伪距的速率不确定性，单位：米每秒
//    private final long ReceivedSvTimeNanos;//在测量时间内，以纳秒为单位获取收到的Gnss卫星事件
//    private final long ReceivedSvTimeUncertainyNanos;//收到的Gnss时间的误差估计值，单位：纳秒
//    private final double SnrInDb;//以dB为单位的信噪比SNR
//    private final int State;//每个卫星的同步状态
//    private final double TimeOffsetNanos;//以纳秒为单位，进行测量的时间偏移

    /*
    类的构造器，接受数据
     */
//    public GnssInfo(double biasNanos, double biasUncertaintyNanos, double driftNanosPerSecond, double driftNanosUncertaintyPerSecond, long fullBaisNanos, int hardwareClockDiscontinuityCount, int leapSecond, long timeNanos, double timeUncertaintyNanos, long carrierCycles, float carrierFrequencyHz, double carrierPhase, double carrierPhaseUncertainty, double cnODbHz, int constellationTpye, int multipathIndicator, double pseudorangeRateMetersPerSecond, double pseudorangeRateUncertaintyMetersPerSecond, long receivedSvTimeNanos, long receivedSvTimeUncertainyNanos, double snrInDb, int state, double timeOffsetNanos) {
//        BiasNanos = biasNanos;
//        BiasUncertaintyNanos = biasUncertaintyNanos;
//        DriftNanosPerSecond = driftNanosPerSecond;
//        DriftNanosUncertaintyPerSecond = driftNanosUncertaintyPerSecond;
//        FullBaisNanos = fullBaisNanos;
//        HardwareClockDiscontinuityCount = hardwareClockDiscontinuityCount;
//        LeapSecond = leapSecond;
//        TimeNanos = timeNanos;
//        TimeUncertaintyNanos = timeUncertaintyNanos;
//        CarrierCycles = carrierCycles;
//        CarrierFrequencyHz = carrierFrequencyHz;
//        CarrierPhase = carrierPhase;
//        CarrierPhaseUncertainty = carrierPhaseUncertainty;
//        CnODbHz = cnODbHz;
//        ConstellationTpye = constellationTpye;
//        MultipathIndicator = multipathIndicator;
//        PseudorangeRateMetersPerSecond = pseudorangeRateMetersPerSecond;
//        PseudorangeRateUncertaintyMetersPerSecond = pseudorangeRateUncertaintyMetersPerSecond;
//        ReceivedSvTimeNanos = receivedSvTimeNanos;
//        ReceivedSvTimeUncertainyNanos = receivedSvTimeUncertainyNanos;
//        SnrInDb = snrInDb;
//        State = state;
//        TimeOffsetNanos = timeOffsetNanos;
//    }

    public GnssInfo(long carrierCycles, float carrierFrequencyHz, double carrierPhase, double carrierPhaseUncertainty) {

        CarrierCycles = carrierCycles;
        CarrierFrequencyHz = carrierFrequencyHz;
        CarrierPhase = carrierPhase;
        CarrierPhaseUncertainty = carrierPhaseUncertainty;

    }



//    public double getBiasNanos() {
//        return BiasNanos;
//    }
//
//    public double getBiasUncertaintyNanos() {
//        return BiasUncertaintyNanos;
//    }
//
//    public double getDriftNanosPerSecond() {
//        return DriftNanosPerSecond;
//    }
//
//    public double getDriftNanosUncertaintyPerSecond() {
//        return DriftNanosUncertaintyPerSecond;
//    }
//
//    public long getFullBaisNanos() {
//        return FullBaisNanos;
//    }
//
//    public int getHardwareClockDiscontinuityCount() {
//        return HardwareClockDiscontinuityCount;
//    }
//
//    public int getLeapSecond() {
//        return LeapSecond;
//    }
//
//    public long getTimeNanos() {
//        return TimeNanos;
//    }
//
//    public double getTimeUncertaintyNanos() {
//        return TimeUncertaintyNanos;
//    }

    public long getCarrierCycles() {
        return CarrierCycles;
    }

    public float getCarrierFrequencyHz() {
        return CarrierFrequencyHz;
    }

    public double getCarrierPhase() {
        return CarrierPhase;
    }

    public double getCarrierPhaseUncertainty() {
        return CarrierPhaseUncertainty;
    }

//    public double getCnODbHz() {
//        return CnODbHz;
//    }
//
//    public int getConstellationTpye() {
//        return ConstellationTpye;
//    }
//
//    public int getMultipathIndicator() {
//        return MultipathIndicator;
//    }
//
//    public double getPseudorangeRateMetersPerSecond() {
//        return PseudorangeRateMetersPerSecond;
//    }
//
//    public double getPseudorangeRateUncertaintyMetersPerSecond() {
//        return PseudorangeRateUncertaintyMetersPerSecond;
//    }
//
//    public long getReceivedSvTimeNanos() {
//        return ReceivedSvTimeNanos;
//    }
//
//    public long getReceivedSvTimeUncertainyNanos() {
//        return ReceivedSvTimeUncertainyNanos;
//    }
//
//    public double getSnrInDb() {
//        return SnrInDb;
//    }
//
//    public int getState() {
//        return State;
//    }
//
//    public double getTimeOffsetNanos() {
//        return TimeOffsetNanos;
//    }


}
