package com.example.minignss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.GnssClock;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.location.GnssMeasurementsEvent;
import android.location.GnssMeasurement;
import android.location.LocationManager;
import android.widget.TextView;

import java.util.Collection;

public class MainActivity extends AppCompatActivity {

    private TextView showText;
    private TextView showText2;
    private TextView showText3;
    private GnssInfo gnssInfo;
    private GnssMeasurementsDATABASE gnssMeasurementsDATABASE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gnssMeasurementsDATABASE = new GnssMeasurementsDATABASE(this);

        showText = findViewById(R.id.showText);
        showText2 = findViewById(R.id.showText2);
        showText3 = findViewById(R.id.showText3);


        GnssMeasurementsEvent.Callback measurement = new GnssMeasurementsEvent.Callback() {
            @Override
            public void onGnssMeasurementsReceived(GnssMeasurementsEvent eventArgs) {
                super.onGnssMeasurementsReceived(eventArgs);

                GnssClock gnssClock = eventArgs.getClock();

                Collection<GnssMeasurement> measurements = eventArgs.getMeasurements();

                for (GnssMeasurement gm :
                        measurements) {

//                    /*
//                    将得到的卫星数据，放在类中
//                     */
//                    gnssInfo= new GnssInfo(gm.getCarrierCycles(),gm.getCarrierFrequencyHz(),gm.getCarrierPhase(),gm.getCarrierPhaseUncertainty());
//                    gnssMeasurementsDATABASE.insertInfo(gnssInfo);

                    showText.setText(String.format(getResources().getString(R.string.Cn0DbHz),gm.getCn0DbHz()));
                    showText2.setText(String.format(getResources().getString(R.string.SnrInDb),gm.getSnrInDb()));
                    showText3.setText(String.format(getResources().getString(R.string.DriftNanosPerSecond),gnssClock.getDriftNanosPerSecond()));

                }
            }
        };

        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.registerGnssMeasurementsCallback(measurement);

        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 0, new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {

            }
        });

    }



}