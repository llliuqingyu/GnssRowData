package com.example.minignss;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class GnssMeasurementsDATABASE extends SQLiteOpenHelper {

    private  static final String DATABASE_NAME = "GnssMeasuresments.db";
    private  static final int VERSION_CODE = 1;
    private  static final String CREATE_TABLE_GNSSMEASURESMENTS = "create table " + DATABASE_NAME + "(id integer primary key autoincrement,CarrierCycles text,CarrierFrequencyHz text,CarrierPhase text,CarrierPhaseUncertainty text)";


    public GnssMeasurementsDATABASE(@Nullable Context context) {
        super(context, DATABASE_NAME, null, VERSION_CODE);

    }




    @Override
    public void onCreate(@NonNull SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_GNSSMEASURESMENTS);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insertInfo(@NonNull GnssInfo gnssInfo){
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values =new ContentValues();

        values.put("CarrierCycles",gnssInfo.getCarrierCycles());
        values.put("CarrierFrequencyHz",gnssInfo.getCarrierFrequencyHz());
        values.put("CarrierPhase",gnssInfo.getCarrierPhase());
        values.put("CarrierPhaseUncertainty",gnssInfo.getCarrierPhaseUncertainty());

        db.insert(DATABASE_NAME,null,values);

    }

}
